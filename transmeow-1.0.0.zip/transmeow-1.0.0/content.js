// 检查是否已经存在全局变量
if (typeof window.transmeowGlobals === 'undefined') {
  window.transmeowGlobals = {
    translationPopup: null,
    lastMouseEvent: null,
    initialized: false,
    clickListener: null
  };
}

// 初始化函数
function initialize() {
  if (window.transmeowGlobals.initialized) return;
  
  // 创建一个固定的容器来放置弹窗
  const container = document.createElement('div');
  container.id = 'transmeow-container';
  container.style.position = 'fixed';
  container.style.top = '0';
  container.style.left = '0';
  container.style.width = '100%';
  container.style.height = '100%';
  container.style.pointerEvents = 'none';
  container.style.zIndex = '999999';
  document.body.appendChild(container);

  // 保存最后的鼠标位置
  document.addEventListener('mouseup', function(e) {
    window.transmeowGlobals.lastMouseEvent = {
      clientX: e.clientX,
      clientY: e.clientY,
      pageX: e.pageX,
      pageY: e.pageY
    };
  });

  // 注入样式表
  if (!document.querySelector('link[href*="styles.css"]')) {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('styles.css');
    document.head.appendChild(link);
  }

  window.transmeowGlobals.initialized = true;
}

// 立即初始化
initialize();

// 监听来自background script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('收到消息:', message);
  
  if (message.action === "showTranslation") {
    showTranslationPopup(message.translation, message.original, message.phonetic, message.sourceLanguage);
  } else if (message.action === "showError") {
    showError(message.message);
  }
});

// 显示翻译结果
function showTranslationPopup(translation, original, phonetic, sourceLanguage) {
  console.log('显示翻译:', { translation, original, phonetic, sourceLanguage });
  
  // 清理现有弹窗
  cleanup();

  // 获取位置信息
  const position = window.transmeowGlobals.lastMouseEvent || {
    clientX: window.innerWidth / 2,
    clientY: window.innerHeight / 2,
    pageX: window.innerWidth / 2,
    pageY: window.innerHeight / 2
  };

  // 创建弹窗
  const popup = document.createElement('div');
  popup.className = 'translation-popup';
  popup.style.position = 'absolute';  // 改为absolute定位
  popup.style.pointerEvents = 'auto';
  
  // 创建原文容器
  const originalDiv = document.createElement('div');
  originalDiv.className = 'original-text';
  originalDiv.textContent = '原文：' + original;
  
  // 添加原文发音按钮
  const originalSpeakButton = createSpeakButton(original, sourceLanguage);
  originalDiv.appendChild(originalSpeakButton);

  // 如果有音标，添加音标显示
  if (phonetic) {
    const phoneticSpan = document.createElement('span');
    phoneticSpan.className = 'phonetic-text';
    phoneticSpan.textContent = phonetic;
    originalDiv.appendChild(phoneticSpan);
  }

  // 创建译文容器
  const translationDiv = document.createElement('div');
  translationDiv.className = 'translation-text';
  translationDiv.textContent = '译文：' + translation;
  
  // 添加译文发音按钮
  const translationSpeakButton = createSpeakButton(translation, 'zh-CN');
  translationDiv.appendChild(translationSpeakButton);

  // 创建关闭按钮容器
  const closeButtonDiv = document.createElement('div');
  closeButtonDiv.className = 'close-button-container';
  
  // 创建关闭按钮
  const closeButton = document.createElement('button');
  closeButton.className = 'close-button';
  closeButton.textContent = '关闭';
  closeButton.onclick = cleanup;
  closeButtonDiv.appendChild(closeButton);

  // 组装所有元素
  popup.appendChild(originalDiv);
  popup.appendChild(translationDiv);
  popup.appendChild(closeButtonDiv);

  // 将弹窗添加到容器中
  const container = document.getElementById('transmeow-container');
  container.appendChild(popup);
  window.transmeowGlobals.translationPopup = popup;

  // 设置初始位置
  const scrollX = window.scrollX || window.pageXOffset;
  const scrollY = window.scrollY || window.pageYOffset;
  
  popup.style.left = `${position.pageX - scrollX}px`;
  popup.style.top = `${position.pageY - scrollY + 10}px`;

  // 调整位置以确保在视口内
  const rect = popup.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  // 水平位置调整
  if (rect.left < 20) {
    popup.style.left = '20px';
    popup.style.transform = 'none';
  } else if (rect.right > viewportWidth - 20) {
    popup.style.left = (viewportWidth - 20) + 'px';
    popup.style.transform = 'translateX(-100%)';
  } else {
    popup.style.transform = 'translateX(-50%)';
  }

  // 垂直位置调整
  if (rect.bottom > viewportHeight - 10) {
    popup.style.top = `${position.pageY - scrollY - rect.height - 10}px`;
  }

  // 设置点击外部关闭
  const handleClickOutside = (e) => {
    if (!popup.contains(e.target)) {
      cleanup();
      document.removeEventListener('click', handleClickOutside);
    }
  };

  // 延迟添加点击监听器，避免立即触发
  setTimeout(() => {
    document.addEventListener('click', handleClickOutside);
  }, 100);
}

// 创建发音按钮
function createSpeakButton(text, lang) {
  const button = document.createElement('button');
  button.innerHTML = '🔊';
  button.className = 'speak-button';
  button.addEventListener('click', (e) => {
    e.stopPropagation();  // 阻止事件冒泡
    chrome.runtime.sendMessage({
      action: 'speak',
      text: text,
      lang: lang === 'en' ? 'en-US' : 'zh-CN'
    });
  });
  return button;
}

// 清理函数
function cleanup() {
  if (window.transmeowGlobals.translationPopup) {
    window.transmeowGlobals.translationPopup.remove();
    window.transmeowGlobals.translationPopup = null;
  }
}

// 显示错误信息
function showError(message) {
  console.log('显示错误:', message);
  
  cleanup();

  const position = window.transmeowGlobals.lastMouseEvent || {
    clientX: window.innerWidth / 2,
    clientY: window.innerHeight / 2,
    pageX: window.innerWidth / 2,
    pageY: window.innerHeight / 2
  };

  const popup = document.createElement('div');
  popup.className = 'error-popup';
  popup.style.position = 'absolute';
  popup.style.pointerEvents = 'auto';

  const scrollX = window.scrollX || window.pageXOffset;
  const scrollY = window.scrollY || window.pageYOffset;
  
  popup.style.left = `${position.pageX - scrollX}px`;
  popup.style.top = `${position.pageY - scrollY + 10}px`;
  popup.textContent = message;

  const container = document.getElementById('transmeow-container');
  container.appendChild(popup);
  window.transmeowGlobals.translationPopup = popup;

  setTimeout(cleanup, 3000);
} 