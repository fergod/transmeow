// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "translateSelection",
    title: "翻译选中文本",
    contexts: ["selection"]
  });
});

// 处理右键菜单点击事件
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "translateSelection") {
    const text = info.selectionText;
    
    try {
      // 注入content script
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });

      // 注入样式
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['styles.css']
      });
      
      // 开始翻译
      translateText(text, tab.id);
    } catch (error) {
      console.error('注入脚本或样式失败:', error);
      // 通知用户出错
      chrome.tabs.sendMessage(tab.id, {
        action: 'showError',
        message: '扩展初始化失败，请刷新页面重试'
      });
    }
  }
});

// 处理来自content script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'speak') {
    chrome.tts.speak(message.text, {
      lang: message.lang,
      rate: 1.0,
      onEvent: function(event) {
        if (event.type === 'error') {
          console.error('TTS Error:', event);
        }
      }
    });
  }
});

// 安全的fetch请求
async function safeFetch(url) {
  try {
    const response = await fetch(url);
    const text = await response.text();
    return JSON.parse(text);
  } catch (error) {
    console.error('Fetch error:', error);
    throw error;
  }
}

// 翻译函数
async function translateText(text, tabId) {
  try {
    // 获取翻译结果
    const translateUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&dt=rm&q=${encodeURIComponent(text)}`;
    const translateData = await safeFetch(translateUrl);
    
    const translatedText = translateData[0][0][0];
    const detectedLang = translateData[2];

    // 如果是英文，获取音标
    let phonetic = '';
    if (detectedLang === 'en') {
      try {
        const phoneticUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(text)}`;
        const phoneticData = await safeFetch(phoneticUrl);
        if (phoneticData[0] && phoneticData[0].phonetic) {
          phonetic = phoneticData[0].phonetic;
        }
      } catch (error) {
        console.log('获取音标失败:', error);
      }
    }

    // 发送翻译结果到content script
    chrome.tabs.sendMessage(tabId, {
      action: 'showTranslation',
      translation: translatedText,
      original: text,
      phonetic: phonetic,
      sourceLanguage: detectedLang
    });
  } catch (error) {
    console.error('翻译失败:', error);
    // 发送错误消息到content script
    chrome.tabs.sendMessage(tabId, {
      action: 'showError',
      message: '翻译失败，请稍后重试'
    });
  }
} 